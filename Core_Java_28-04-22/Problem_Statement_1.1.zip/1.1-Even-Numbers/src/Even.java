import java.util.Scanner;

public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner= new Scanner(System.in);
		System.out.println("enter the highest value");
		int n=scanner.nextInt();
		for(int i=1;i<=n;i++)
		
		{
			if(i%2==0)
				System.out.print(" "+i);
			
		}
		System.out.println();
		
		
	}

}
